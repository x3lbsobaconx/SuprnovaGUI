Before using this software, there must be a folder containg the Suprnova nheqminer in the same folder running the .exe file. I have put the most recent miner in the folder already but if you use a different miner make sure the .exe is named nheqminer.

To use this, just fill out the details and press "Start Mining!"

That's all. You will start mining. Please note that the console output is not realtime at this moment, but it will update at some points. Use the Show CMD option for now.